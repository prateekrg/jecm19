package com.prateek.otoApp.util;

import com.prateek.otoApp.dao.Body_BrainDao;
import com.prateek.otoApp.dto.BodyDto;
import com.prateek.otoApp.dto.BrainDto;

public class Tester {

	public static void main(String[] args) {
		
		BodyDto body=new BodyDto();
		body.setWeight(68);
		body.setHight(4);
		body.setColour("brown");
		
		BrainDto brain=new BrainDto();
		brain.setColour("red");
		brain.setNerves(150);
		brain.setCapacity(1000);
		
		
		brain.setBodyDto(body);
		body.setBrainDto(brain);
		
		Body_BrainDao dao=new Body_BrainDao();
		
		//dao.saveDetails(body);
		
		BodyDto dto=dao.getAllData("brown");
		System.out.println(dto.getWeight());
		System.out.println(dto.getBrainDto().getNerves());
		
	}
}
