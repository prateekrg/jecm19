package com.prateek.otoApp.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.prateek.hibernate.util.HibernateUtil;
import com.prateek.otoApp.dto.BodyDto;

public class Body_BrainDao {

	public void saveDetails(BodyDto body) {
		Session session=HibernateUtil.getSessionFactory().openSession();
		Transaction tx=session.beginTransaction();
		try {
			session.save(body);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		finally{
			session.close();
		}
		
	}

	public BodyDto getAllData(String colour) {
		Session session=HibernateUtil.getSessionFactory().openSession();
		String syntx="select dto from BodyDto dto where dto.colour='"+colour+"'";
		try {
			Query query=session.createQuery(syntx);
			BodyDto dto=(BodyDto) query.uniqueResult();
			return dto;
		} catch (Exception e) {
			return null;
		}finally{
			session.close();
		}
		
		
	}

	
	
}
