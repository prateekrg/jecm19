package com.prateek.otoApp.dto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class BrainDto {
	
	@Id
	@GenericGenerator(name="brain_seq",strategy="increment")
	@GeneratedValue(generator="brain_seq")
	private int id;
	private String colour;
	private int capacity;
	private int nerves;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="b_id")
	private BodyDto bodyDto;
	
	public BrainDto() {
		System.out.println(this.getClass().getSimpleName()+"  is created...");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public int getNerves() {
		return nerves;
	}

	public void setNerves(int nerves) {
		this.nerves = nerves;
	}

	public BodyDto getBodyDto() {
		return bodyDto;
	}

	public void setBodyDto(BodyDto bodyDto) {
		this.bodyDto = bodyDto;
	}
	

}
