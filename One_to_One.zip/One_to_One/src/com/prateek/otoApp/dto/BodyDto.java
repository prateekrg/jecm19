package com.prateek.otoApp.dto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class BodyDto {

	@Id
	@GenericGenerator(name="body_seq",strategy="increment")
	@GeneratedValue(generator="body_seq")
	private int id;
	private int weight;
	private String colour;
	private double hight;
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@PrimaryKeyJoinColumn
	BrainDto brainDto;
	
	public BodyDto() {
		System.out.println(this.getClass().getSimpleName()+"  is created..");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public double getHight() {
		return hight;
	}

	public void setHight(double hight) {
		this.hight = hight;
	}

	public BrainDto getBrainDto() {
		return brainDto;
	}

	public void setBrainDto(BrainDto brainDto) {
		this.brainDto = brainDto;
	}
	
}
