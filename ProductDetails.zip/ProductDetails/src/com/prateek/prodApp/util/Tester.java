package com.prateek.prodApp.util;

import com.prateek.prodApp.dao.ProductDao;
import com.prateek.prodApp.dto.ProductDto;

public class Tester {

	public static void main(String[] args) {
		
		ProductDto dto=new ProductDto();
		dto.setId(10);
		dto.setName("pen");
		dto.setPrice(100);
		dto.setQuantity(1);
		dto.setType("ballpen");
	
		ProductDao dao=new ProductDao();
		dao.saveProduct(dto);
		
	}
}
