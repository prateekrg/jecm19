package com.prateek.prodApp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.prateek.utilApp.HibernateUtil;

import com.prateek.prodApp.dto.ProductDto;

public class ProductDao {

	public void saveProduct(ProductDto dto) {
	SessionFactory factory=HibernateUtil.getSessionFactory();
	Session session=factory.openSession();
	Transaction tx=session.beginTransaction();
	session.save(dto);
	tx.commit();
	session.close();
	
		
	}

}
