package com.prateek.bankApp.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import org.hibernate.annotations.GenericGenerator;

@Entity
@NamedQueries({
	@NamedQuery(name="BankEntity.getifscCodeByName",query="select b.ifsccode from BankEntity b where b.bankname=:bnk"),
	@NamedQuery(name="BankEntity.getdataByname",query="select b.ifsccode, b.branch,b.address from BankEntity b where b.bankname=:bnk")
})

public class BankEntity {

	@Id
	@GenericGenerator(name="bank_seq",strategy="increment")
	@GeneratedValue(generator="bank_seq")
	private int id;
	private String bankname;
	private String ifsccode;
	private String branch;
	private String address;
	
	public BankEntity() {
		System.out.println(this.getClass().getSimpleName()+" is created....");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getIfsccode() {
		return ifsccode;
	}

	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
