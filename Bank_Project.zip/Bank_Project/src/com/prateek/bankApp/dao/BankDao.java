package com.prateek.bankApp.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.prateek.utilApp.HibernateUtil;

import com.prateek.bankApp.dto.BankEntity;

public class BankDao {

	public void saveBank(BankEntity entity) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();

		try {
			session.save(entity);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		finally{
			session.close();
		}

	}

	public String getifscCodeByName(String bankname) {
		Session session = HibernateUtil.getSessionFactory().openSession();
	//	String syntx="select b.ifsccode from BankEntity b where b.bankname=:bnk";
	String ifsc=null;
		try {
		Query qry=session.getNamedQuery("BankEntity.getifscCodeByName");
		qry.setParameter("bnk",bankname );
		ifsc=(String) qry.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			session.close();
		}
		
		return ifsc;
	}

	public void getdataByname(String name) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		try {
			Query qry=session.getNamedQuery("BankEntity.getdataByname");
			qry.setParameter("bnk", name);
		     List<Object[]> obj1=  qry.list();
		     for (Iterator iterator = obj1.iterator(); iterator.hasNext();) {
				Object[] obj = (Object[]) iterator.next();
				   System.out.println("obj[0]---->"+obj[0]);
				      System.out.println("obj[1]---->"+obj[1]);
				      System.out.println("obj[2]---->"+obj[2]);
			}
		   
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			session.close();
		}
		
		
	}

}
