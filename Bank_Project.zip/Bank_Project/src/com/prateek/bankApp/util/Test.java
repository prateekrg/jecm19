package com.prateek.bankApp.util;

import com.prateek.bankApp.dao.BankDao;
import com.prateek.bankApp.dto.BankEntity;

public class Test {

	public static void main(String[] args) {
		BankEntity entity=new BankEntity();
		entity.setBankname("CANARa");
		entity.setIfsccode("cnr0000123");
		entity.setBranch("channagiri");
		entity.setAddress("Davanagere");
		
		BankDao dao=new BankDao();
		dao.saveBank(entity);
		
		String ifsc=dao.getifscCodeByName("Bank of Maharastra");
		System.out.println(ifsc);
		dao.getdataByname("SBI");
		
	}
}
