package org.prateek.utilApp;

public class Tester {

	public static void main(String[] args) {
		System.out.println(HibernateUtil.getSessionFactory().hashCode());
		System.out.println(HibernateUtil.getSessionFactory().hashCode());
		
	}
}
