package com.prateek.app.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.prateek.app.dto.RegisterDto;
import com.prateek.app.service.LoginService;

@Controller
@RequestMapping("/")
public class LoginController {
	
	@Autowired
	LoginService loginService;

	@RequestMapping(value="login.do" ,method={RequestMethod.POST,RequestMethod.GET})
	public String register(HttpServletRequest request)
	{
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		RegisterDto registerDto=loginService.checkUser(username,password);
		if(registerDto!=null)
		{
			request.setAttribute("name", registerDto.getName());
			return "/success.jsp";
		}
		else
			return "/error.jsp";
	}
}
