package com.prateek.app.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.prateek.app.dto.RegisterDto;
import com.prateek.app.service.RegisterService;
@Controller
@RequestMapping("/")
public class RegisterController {
	@Autowired
	RegisterService registerService;
	@RequestMapping(value="register.do" ,method={RequestMethod.POST,RequestMethod.GET})
	public String register(@ModelAttribute RegisterDto registerDto,HttpServletRequest request)
	{
		System.out.println("-----inside controller---");
		
		if(registerDto!=null)
		{
			registerService.save(registerDto);
		}
		
		return "/regSucesss.jsp";
	}
}
