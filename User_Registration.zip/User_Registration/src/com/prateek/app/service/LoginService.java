package com.prateek.app.service;

import com.prateek.app.dto.RegisterDto;

public interface LoginService {

	RegisterDto checkUser(String username, String password);

}
