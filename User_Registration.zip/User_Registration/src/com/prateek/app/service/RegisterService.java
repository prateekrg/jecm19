package com.prateek.app.service;

import com.prateek.app.dto.RegisterDto;

public interface RegisterService {

	void save(RegisterDto registerDto);

}
