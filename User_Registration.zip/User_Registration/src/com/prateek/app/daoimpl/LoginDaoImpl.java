package com.prateek.app.daoimpl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.prateek.utilApp.HibernateUtil;
import org.springframework.stereotype.Repository;

import com.prateek.app.dao.LoginDao;
import com.prateek.app.dto.RegisterDto;
@Repository
public class LoginDaoImpl implements LoginDao{

	@Override
	public RegisterDto checkUser(String username, String password) {
		Session session=HibernateUtil.getSessionFactory().openSession();
		String qry="select a from RegisterDto a where username='"+username+"' and password='"+password+"'";
		try {
			Query synx=session.createQuery(qry);
			RegisterDto registerDto =(RegisterDto) synx.uniqueResult();
			return registerDto;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
