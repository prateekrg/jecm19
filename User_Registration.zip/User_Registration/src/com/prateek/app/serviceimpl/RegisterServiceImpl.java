package com.prateek.app.serviceimpl;


import org.hibernate.Session;
import org.hibernate.Transaction;
import org.prateek.utilApp.HibernateUtil;
import org.springframework.stereotype.Service;
import com.prateek.app.dto.RegisterDto;
import com.prateek.app.service.RegisterService;
@Service
public class RegisterServiceImpl implements RegisterService{
	@Override
	public void save(RegisterDto registerDto) 
	{
		Session session=HibernateUtil.getSessionFactory().openSession();
		Transaction tx=session.beginTransaction();
		try {
			session.save(registerDto);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		finally{
			session.close();
		}
		System.out.println("---saved successfully---");
	}

}
