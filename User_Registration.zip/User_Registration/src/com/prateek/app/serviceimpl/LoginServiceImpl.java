package com.prateek.app.serviceimpl;

import org.hibernate.Session;
import org.prateek.utilApp.HibernateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prateek.app.dao.LoginDao;
import com.prateek.app.dto.RegisterDto;
import com.prateek.app.service.LoginService;
@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	LoginDao loginDao;
	
	@Override
	public RegisterDto checkUser(String username, String password) {
		
		
		return loginDao.checkUser(username,password);
	}

	
	
}
