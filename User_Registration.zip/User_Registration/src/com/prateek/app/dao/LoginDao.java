package com.prateek.app.dao;

import com.prateek.app.dto.RegisterDto;

public interface LoginDao {

	RegisterDto checkUser(String username, String password);

}
