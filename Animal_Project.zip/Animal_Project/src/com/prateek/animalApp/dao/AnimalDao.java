package com.prateek.animalApp.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jece11.hibernateApp.HibernateUtil;
import com.prateek.animalApp.dto.AnimalDto;

public class AnimalDao {

	public void saveAnimal(AnimalDto dto) {
		Session session=HibernateUtil.getFactory().openSession();
		Transaction tx=session.beginTransaction();
		session.save(dto);
		tx.commit();
		session.close();
	}

	public String getColourByName(String name) {
		Session session=HibernateUtil.getFactory().openSession();
		String syntx="select animal.colour from AnimalDto animal where animal.name='"+name+"'  ";
		Query qry=session.createQuery(syntx);
		String colour=(String) qry.uniqueResult();
		session.close();
		return colour;
	}

}
