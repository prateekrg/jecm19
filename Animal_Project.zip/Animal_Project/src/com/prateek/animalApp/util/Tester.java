package com.prateek.animalApp.util;

import com.prateek.animalApp.dao.AnimalDao;
import com.prateek.animalApp.dto.AnimalDto;

public class Tester {

	public static void main(String[] args) {
		
		AnimalDao dao=new AnimalDao();
		String colour=dao.getColourByName("dog");
		System.out.println("colour of dog is : "+colour);
		
		
		
	}
}
