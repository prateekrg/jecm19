package com.prateek.animalApp.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class AnimalDto {

	@Id
	@GenericGenerator(name="animal_seq",strategy="increment")
	@GeneratedValue(generator="animal_seq")
	private int id;
	private String name;
	private String type;
	private String colour;
	
	public AnimalDto() {
		System.out.println(this.getClass().getSimpleName()+"  is craeted...");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}
	
}
