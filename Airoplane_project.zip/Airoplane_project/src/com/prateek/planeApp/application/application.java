package com.prateek.planeApp.application;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.prateek.planeApp.bean.Airoplane;

public class application {

	public static void main(String[] args) {

		String xml = "spring.xml";
		Resource resource = new ClassPathResource(xml);

		BeanFactory container = new XmlBeanFactory(resource);
		//Airoplane bean = container.getBean(Airoplane.class);
	     Airoplane bean = container.getBean("airoplane1",Airoplane.class);
		bean.flying();
	}
}
