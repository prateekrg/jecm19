package com.prateek.planeApp.bean;

public class Airoplane {

	private String colour;
	private String name;
	
	public void setColour(String colour) {
		this.colour = colour;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void flying()
	{
		System.out.println(name+" "+colour+" coloured airoplane is flying....");
	}
}
