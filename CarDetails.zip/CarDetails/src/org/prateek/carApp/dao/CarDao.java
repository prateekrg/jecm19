package org.prateek.carApp.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.prateek.carApp.dto.CarDto;

public class CarDao {

	public void saveCar(CarDto dto) {
		System.out.println("---------saving---------");
		Configuration cfg = new Configuration();
		cfg.configure("mysql.cfg.xml");
		cfg.addAnnotatedClass(CarDto.class);
		SessionFactory factory = cfg.buildSessionFactory();

		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(dto);
		tx.commit();
		session.close();
		System.out.println("---------saved---------");
	}

	public CarDto getCarByPk(int pk) {

		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(CarDto.class);
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		CarDto dto = session.get(CarDto.class, pk);
		return dto;
	}

	public void updateColourByPk(int pk) {
		System.out.println("------------updating-------");
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(CarDto.class);
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		CarDto dto = session.get(CarDto.class, pk);
		dto.setColour("MatBlack");
		session.update(dto);

		tx.commit();
		session.close();
		System.out.println("----------updated------------");
	}

	public void deleteCarByPk(int pk) {
		System.out.println("------------deleting-------");
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(CarDto.class);
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();	
		CarDto dto = session.get(CarDto.class, pk);
		session.delete(dto);
		tx.commit();
		session.close();
		System.out.println("------------deleted-------");
	}

}
