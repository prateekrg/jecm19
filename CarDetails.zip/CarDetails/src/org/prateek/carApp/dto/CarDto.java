package org.prateek.carApp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Car")
public class CarDto  implements Serializable{

	@Column(name="colour")
	private String colour;
	
	@Column(name="price")
	private double price;
	
	@Column(name="brand")
	private String brand;

	@Id
	@Column(name="id")
	private int id;
	
	public CarDto() {
		System.out.println(this.getClass().getSimpleName()+" is creatd...");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}
	
}
