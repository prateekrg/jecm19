package org.prateek.carApp.util;

import org.prateek.carApp.dao.CarDao;
import org.prateek.carApp.dto.CarDto;

public class Test {

	public static void main(String[] args) {
		
		
	CarDao dao=new CarDao();
	//CarDto dto=dao.getCarByPk(3);
	//System.out.println(dto.getBrand() + "  "+dto.getColour() + " "+dto.getPrice());	
		
	//dao.updateColourByPk(3);
	
	dao.deleteCarByPk(2);
	}
}
