package com.prateek.app.bean;

public class HospitalBean {

	String tablets;
	public HospitalBean() {
		System.out.println(this.getClass().getName()+"  is created...");
	}
	public HospitalBean(String tablets) {
		this.tablets=tablets;
		System.out.println(this.getClass().getName()+"  is created...");
	}
	public void medicalServices()
	{
		System.out.println("mediacl services are providing");
	}
	public String getTablets() {
		return tablets;
	}
	
	
}
