package com.prateek.app.application;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.prateek.app.bean.HospitalBean;

public class Application {

	public static void main(String[] args) {

		ApplicationContext spring = new ClassPathXmlApplicationContext(
				"spring.xml");
		HospitalBean bean = spring.getBean("hospital",HospitalBean.class);
			bean.medicalServices();
	    HospitalBean hospital1 = spring.getBean("hospital1",HospitalBean.class);
	    System.out.println(hospital1.getTablets());
	}
}
