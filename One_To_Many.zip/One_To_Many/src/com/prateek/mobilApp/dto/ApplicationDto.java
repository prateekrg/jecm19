package com.prateek.mobilApp.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class ApplicationDto {


	@Id
	@GenericGenerator(name="mobile_seq",strategy="increment")
	@GeneratedValue(generator="mobile_seq")
	private int id;
	private String a_name;
	private String features;
	private double size;
	
	@ManyToOne
	@JoinColumn(name="m_id")
	private MobileDto mobileDto;
	public ApplicationDto() {
		System.out.println(this.getClass().getName()+" is craeted...");
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getA_name() {
		return a_name;
	}
	public void setA_name(String a_name) {
		this.a_name = a_name;
	}
	public String getFeatures() {
		return features;
	}
	public void setFeatures(String features) {
		this.features = features;
	}
	public double getSize() {
		return size;
	}
	public void setSize(double size) {
		this.size = size;
	}
	public MobileDto getMobileDto() {
		return mobileDto;
	}
	public void setMobileDto(MobileDto mobileDto) {
		this.mobileDto = mobileDto;
	}
	
	
}
