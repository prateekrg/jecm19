package com.prateek.mobilApp.dto;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class MobileDto {

	@Id
	@GenericGenerator(name="mobile_seq",strategy="increment")
	@GeneratedValue(generator="mobile_seq")
	private int id;
	private String brand;
	private double price;
	private String colour;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER,targetEntity=ApplicationDto.class,mappedBy="mobileDto")
	private Collection<ApplicationDto> applicationDto;
	public MobileDto() {
		System.out.println(this.getClass().getSimpleName()+" is created...");
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public Collection<ApplicationDto> getApplicationDto() {
		return applicationDto;
	}
	public void setApplicationDto(Collection<ApplicationDto> applicationDto) {
		this.applicationDto = applicationDto;
	}
	
	
}
