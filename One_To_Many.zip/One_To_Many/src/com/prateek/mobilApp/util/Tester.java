package com.prateek.mobilApp.util;

import java.util.ArrayList;

import com.prateek.mobilApp.dao.Mobil_AppDao;
import com.prateek.mobilApp.dto.ApplicationDto;
import com.prateek.mobilApp.dto.MobileDto;

public class Tester {

	public static void main(String[] args) {
		
		MobileDto mobile=new MobileDto();
		mobile.setBrand("Samsung");
		mobile.setPrice(20000);
		mobile.setColour("white");
		
		ApplicationDto app1=new ApplicationDto();
		app1.setA_name("Whatsapp");
		app1.setFeatures("call,chat");
		app1.setSize(13);
		app1.setMobileDto(mobile);

		ApplicationDto app2=new ApplicationDto();
		app2.setA_name("instagram");
		app2.setFeatures("surf post");
		app2.setSize(10);
		app2.setMobileDto(mobile);

		ArrayList applications=new ArrayList();
		
		applications.add(app1);
		applications.add(app2);
		
		mobile.setApplicationDto(applications);
		
		Mobil_AppDao dao=new Mobil_AppDao();
		dao.saveDetails(mobile);
		
		
	    
	}
}
