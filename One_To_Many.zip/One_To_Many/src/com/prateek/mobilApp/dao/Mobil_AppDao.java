package com.prateek.mobilApp.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.prateek.hibernate.util.HibernateUtil;
import com.prateek.mobilApp.dto.MobileDto;

public class Mobil_AppDao {

	public void saveDetails(MobileDto mobile) {
		Session session=HibernateUtil.getSessionFactory().openSession();
		Transaction tx=session.beginTransaction();
		try {
			session.save(mobile);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		finally{
			session.close();
		}
		
	}

}
