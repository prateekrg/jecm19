package com.prateek.app.Application;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.prateek.app.bean.Mobile;

public class Application {

	public static void main(String[] args) {
		
		String xml="init.xml";
		ApplicationContext container=new ClassPathXmlApplicationContext(xml);
		Mobile mob=container.getBean(Mobile.class);
		mob.switchon(100);
		
	}
}
