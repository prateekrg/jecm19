package com.prateek.app.bean;

public class Mobile {

	Battery battery;
	
	/*public Mobile(Battery battery) {
		this.battery=battery;
		System.out.println(this.getClass().getSimpleName()+" is created..");
	}*/
	public void switchon(int percentage)
	{
	
		if(battery!=null)
			battery.store(percentage);
		else
			System.out.println("Battery doesn't exist");
	}

	public Battery getBattery() {
		return battery;
	}

	public void setBattery(Battery battery) {
		this.battery = battery;
	}
	
}
