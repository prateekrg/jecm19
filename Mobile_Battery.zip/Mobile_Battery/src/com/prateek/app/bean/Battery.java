package com.prateek.app.bean;

public class Battery {

	public Battery() {
		System.out.println(this.getClass().getName()+" is created..");
	}
	
	public void store(int percentage)
	{
		System.out.println("battery percent is "+percentage);
	}
}
