package com.prateek.app.controller;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Component
@RequestMapping("/")
public class AdharController {

	@RequestMapping(value="register.do" ,method={RequestMethod.GET,RequestMethod.POST})
	public String register(
			@RequestParam("name")String nm,
			@RequestParam("phno")Long phno,
			@RequestParam("address")String address,
			@RequestParam("adhno")Long num,
			HttpServletRequest request){
		request.setAttribute("disp", nm+"  "+phno+" "+address+" "+num);
		return "/displayInfo";	
		
	}
}
